const PHONE = '01016258466';
const WA = '201016258466';
const DELIVERY_FEE = 30;

const ASSETS = {
  logo: 'assets/logo.png',
  hero: 'assets/items/pink-valley-4pcs.jpg',
  sushi: 'assets/items/philadelphia-4pcs.jpg',
  special: 'assets/items/pink-valley-4pcs.jpg',
  combos: 'assets/items/combo-35-of-your-choice.jpg',
  crab: 'assets/items/crab-salad.jpg',
  noodles: 'assets/items/noodles-veg.jpg'
};

const ITEM_IMAGES = {
  'philadelphia 4pcs': 'assets/items/philadelphia-4pcs.jpg',
  'philadelphia roll': 'assets/items/philadelphia-4pcs.jpg',
  'new style philadelphia 4pcs': 'assets/items/new-style-philadelphia-4pcs.jpg',
  'new style philadelphia': 'assets/items/new-style-philadelphia-4pcs.jpg',
  'cloud roll 4pcs': 'assets/items/cloud-roll-4pcs.jpg',
  'cloud roll': 'assets/items/cloud-roll-4pcs.jpg',
  'crispy roll 4pcs': 'assets/items/crispy-roll-4pcs.jpg',
  'crispy roll': 'assets/items/crispy-roll-4pcs.jpg',
  'wild roll 4pcs': 'assets/items/wild-roll-4pcs.jpg',
  'wild roll': 'assets/items/wild-roll-4pcs.jpg',
  'phili crispy 4pcs': 'assets/items/phili-crispy-4pcs.jpg',
  'phili crispy': 'assets/items/phili-crispy-4pcs.jpg',
  'lava roll 4pcs': 'assets/items/lava-roll-4pcs.jpg',
  'lava roll': 'assets/items/lava-roll-4pcs.jpg',
  'royal roll 4pcs': 'assets/items/royal-roll-4pcs.jpg',
  'royal roll': 'assets/items/royal-roll-4pcs.jpg',
  'spicy lemon 4pcs': 'assets/items/spicy-lemon-4pcs.jpg',
  'spicy lemon': 'assets/items/spicy-lemon-4pcs.jpg',
  'flame roll 4pcs': 'assets/items/flame-roll-4pcs.jpg',
  'flame roll': 'assets/items/flame-roll-4pcs.jpg',
  'spicy salmon 4pcs': 'assets/items/spicy-salmon-4pcs.jpg',
  'spicy salmon': 'assets/items/spicy-salmon-4pcs.jpg',
  'shell roll 4pcs': 'assets/items/shell-roll-4pcs.jpg',
  'shell roll': 'assets/items/shell-roll-4pcs.jpg',
  'crispy tampura 4pcs': 'assets/items/crispy-tampura-4pcs.jpg',
  'crispy tampura': 'assets/items/crispy-tampura-4pcs.jpg',
  'hoso maki salmon 4pcs': 'assets/items/hoso-maki-salmon-4pcs.jpg',
  'hoso maki salmon': 'assets/items/hoso-maki-salmon-4pcs.jpg',
  'hoso maki shrimp 4pcs': 'assets/items/hoso-maki-shrimp-4pcs.jpg',
  'hoso maki shrimp': 'assets/items/hoso-maki-shrimp-4pcs.jpg',
  'hoso maki crab 4pcs': 'assets/items/hoso-maki-crab-4pcs.jpg',
  'hoso maki crab': 'assets/items/hoso-maki-crab-4pcs.jpg',
  'smoky crunch roll 4pcs': 'assets/items/smoky-crunch-roll-4pcs.jpg',
  'smoky crunch roll': 'assets/items/smoky-crunch-roll-4pcs.jpg',
  'black panther roll 4pcs': 'assets/items/black-panther-roll-4pcs.jpg',
  'black panther roll': 'assets/items/black-panther-roll-4pcs.jpg',
  'pink valley 4pcs': 'assets/items/pink-valley-4pcs.jpg',
  'pink valley': 'assets/items/pink-valley-4pcs.jpg',
  'pink valley roll': 'assets/items/pink-valley-4pcs.jpg',
  'nori cheese bomb 4pcs': 'assets/items/nori-cheese-bomb-4pcs.jpg',
  'nori cheese bomb': 'assets/items/nori-cheese-bomb-4pcs.jpg',
  'mango heat roll 4pcs': 'assets/items/mango-heat-roll-4pcs.jpg',
  'mango heat roll': 'assets/items/mango-heat-roll-4pcs.jpg',
  'spicy lava roll 4pcs': 'assets/items/spicy-lava-roll-4pcs.jpg',
  'spicy lava roll': 'assets/items/spicy-lava-roll-4pcs.jpg',
  'nori signature roll 4pcs': 'assets/items/nori-signature-roll-4pcs.jpg',
  'nori signature roll': 'assets/items/nori-signature-roll-4pcs.jpg',
  'avocado creamy roll 4pcs': 'assets/items/avocado-creamy-roll-4pcs.jpg',
  'avocado creamy roll': 'assets/items/avocado-creamy-roll-4pcs.jpg',
  'noodles veg': 'assets/items/noodles-veg.jpg',
  'noodles shrimp': 'assets/items/noodles-shrimp.jpg',
  'noodles chicken': 'assets/items/noodles-chicken.jpg',
  'crab salad': 'assets/items/crab-salad.jpg',
  'spicy mayo': 'assets/items/spicy-mayo.jpg',
  'teriyaki': 'assets/items/teriyaki.jpg',
  'soy sauce': 'assets/items/soy-sauce.jpg',
  'wasabi': 'assets/items/wasabi.jpg',
  'ginger': 'assets/items/ginger.jpg',
  'chopsticks': 'assets/items/chopsticks.jpg',
  'combo 12': 'assets/items/combo-12.jpg',
  'combo 16': 'assets/items/combo-16.jpg',
  'combo 24': 'assets/items/combo-24.jpg',
  'combo 35 of your choice': 'assets/items/combo-35-of-your-choice.jpg',
  'combo 40 of your choice except special rolls': 'assets/items/combo-40-of-your-choice-except-special-rolls.jpg'
};

const menuData = {
  'Sushi Menu': [
    { name:'Philadelphia 4pcs', price:129, ingredients:'Salmon, cream cheese, cucumber, avocado, sushi rice, nori' },
    { name:'New Style Philadelphia 4pcs', price:135, ingredients:'Salmon, cream cheese, avocado, spicy mayo, sesame, spring onion' },
    { name:'Cloud Roll 4pcs', price:125, ingredients:'Salmon, avocado, cream cheese, white sauce, sesame, sushi rice' },
    { name:'Crispy Roll 4pcs', price:119, ingredients:'Crispy shrimp, cucumber, avocado, spicy mayo, crunchy flakes' },
    { name:'Wild Roll 4pcs', price:119, ingredients:'Salmon, avocado, cucumber, sesame, special sauce' },
    { name:'Phili Crispy 4pcs', price:125, ingredients:'Crispy shrimp, cream cheese, avocado, spicy mayo, crunchy topping' },
    { name:'Lava Roll 4pcs', price:119, ingredients:'Salmon, avocado, cucumber, spicy lava sauce, sesame' },
    { name:'Royal Roll 4pcs', price:109, ingredients:'Salmon, cream cheese, cucumber, tobiko, special sauce' },
    { name:'Spicy Lemon 4pcs', price:129, ingredients:'Salmon, lemon sauce, avocado, cucumber, sesame, spring onion' },
    { name:'Flame Roll 4pcs', price:129, ingredients:'Salmon, avocado, cucumber, flame sauce, crispy flakes' },
    { name:'Spicy Salmon 4pcs', price:119, ingredients:'Spicy salmon, avocado, cucumber, spicy mayo, sesame' },
    { name:'Shell Roll 4pcs', price:125, ingredients:'Shrimp, avocado, cream cheese, sesame, special sauce' },
    { name:'Crispy Tampura 4pcs', price:119, ingredients:'Tempura shrimp, avocado, cucumber, crunchy flakes, spicy mayo' },
    { name:'Hoso Maki Salmon 4pcs', price:90, ingredients:'Salmon, sushi rice, nori' },
    { name:'Hoso Maki Shrimp 4pcs', price:90, ingredients:'Shrimp, sushi rice, nori' },
    { name:'Hoso Maki Crab 4pcs', price:70, ingredients:'Crab stick, sushi rice, nori' }
  ],
  'Special Rolls': [
    { name:'Smoky Crunch Roll 4pcs', price:159, ingredients:'Salmon, shrimp, avocado, smoky sauce, crunchy topping, sesame' },
    { name:'Black Panther Roll 4pcs', price:149, ingredients:'Black nori, salmon, cream cheese, avocado, spicy sauce, sesame' },
    { name:'Pink Valley 4pcs', price:139, ingredients:'Pink sushi rice, salmon, cream cheese, avocado, spicy mayo, tobiko' },
    { name:'Nori Cheese Bomb 4pcs', price:139, ingredients:'Crab, cream cheese, avocado, white rice, tobiko, sesame' },
    { name:'Mango Heat Roll 4pcs', price:145, ingredients:'Mango, salmon, cream cheese, avocado, spicy mango sauce, tobiko' },
    { name:'Spicy Lava Roll 4pcs', price:139, ingredients:'Salmon, cream cheese, avocado, spicy lava sauce, sesame' },
    { name:'Nori Signature Roll 4pcs', price:159, ingredients:'Salmon, shrimp, avocado, cream cheese, black nori, signature sauce' },
    { name:'Avocado Creamy Roll 4pcs', price:139, ingredients:'Avocado, cream cheese, shrimp, cucumber, creamy sauce, sesame' }
  ],
  'Sides': [
    { name:'Noodles Veg', price:85, ingredients:'Noodles, mixed vegetables, teriyaki sauce, sesame, spring onion' },
    { name:'Noodles Shrimp', price:179, ingredients:'Noodles, shrimp, vegetables, teriyaki sauce, sesame, spring onion' },
    { name:'Noodles Chicken', price:135, ingredients:'Noodles, chicken, vegetables, teriyaki sauce, sesame, spring onion' },
    { name:'Crab Salad', price:119, ingredients:'Crab sticks, cucumber, avocado, mayo, sesame, spring onion' },
    { name:'Spicy Mayo', price:25, ingredients:'Mayo, chili sauce, sesame oil' },
    { name:'Teriyaki', price:25, ingredients:'Soy sauce, sugar, ginger, garlic' },
    { name:'Soy Sauce', price:20, ingredients:'Classic soy sauce' },
    { name:'Wasabi', price:15, ingredients:'Wasabi paste' },
    { name:'Ginger', price:15, ingredients:'Pickled ginger' },
    { name:'Chopsticks', price:5, ingredients:'Wooden chopsticks' }
  ],
  'Combos': [
    { name:'Combo 12', price:279, oldPrice:399, badge:'Best Value', ingredients:'Philadelphia, crispy roll, cloud roll' },
    { name:'Combo 16', price:379, oldPrice:549, badge:'Most Ordered', ingredients:'New style Philadelphia, spicy lemon, royal roll, shell roll' },
    { name:'Combo 24', price:649, oldPrice:849, badge:'Party Combo', ingredients:'New style Philadelphia, flame roll, cloud roll, wild roll, crispy roll, spicy salmon' },
    { name:'Combo 35 of your choice', price:1299, oldPrice:1649, badge:'Limited Offer', ingredients:'35 pieces from all regular sushi and special rolls. Choose Bank El Haz (1299) or Snakes & Ladders (1279).' },
    { name:'Combo 40 of your choice except special rolls', price:1149, oldPrice:1399, badge:'Save More', ingredients:'40 pieces from regular sushi only (no special rolls). Choose Bank El Haz (1149) or Snakes & Ladders (1129).' }
  ],
  'Sauces': [
    { name:'Spicy Mayo', price:25, ingredients:'Mayo, chili sauce, sesame oil' },
    { name:'Teriyaki', price:25, ingredients:'Soy sauce, sugar, ginger, garlic' },
    { name:'Soy Sauce', price:20, ingredients:'Classic soy sauce' },
    { name:'Wasabi', price:15, ingredients:'Wasabi paste' },
    { name:'Ginger', price:15, ingredients:'Pickled ginger' }
  ]
};

const featuredProducts = [
  { name:'Pink Valley 4pcs', price:139, category:'Special Rolls', ingredients:'Pink sushi rice, salmon, cream cheese, avocado, spicy mayo, tobiko' },
  { name:'Philadelphia 4pcs', price:129, category:'Sushi Menu', ingredients:'Salmon, cream cheese, cucumber, avocado, sushi rice, nori' },
  { name:'New Style Philadelphia 4pcs', price:135, category:'Sushi Menu', ingredients:'Salmon, cream cheese, avocado, spicy sauce, sesame, spring onion' },
  { name:'Cloud Roll 4pcs', price:125, category:'Sushi Menu', ingredients:'Salmon, avocado, cream cheese, white sauce, sesame' },
  { name:'Crispy Roll 4pcs', price:119, category:'Sushi Menu', ingredients:'Crispy shrimp, avocado, cucumber, spicy mayo, crunchy flakes' },
  { name:'Crab Salad', price:119, category:'Sides', ingredients:'Crab sticks, cucumber, avocado, mayo, sesame, spring onion' },
  { name:'Noodles Veg', price:85, category:'Sides', ingredients:'Noodles, mixed vegetables, teriyaki sauce, sesame, spring onion' },
  { name:'Noodles Shrimp', price:179, category:'Sides', ingredients:'Noodles, shrimp, vegetables, teriyaki sauce, sesame, spring onion' }
];

let cart = JSON.parse(localStorage.getItem('noriCart') || '[]');
let currentProduct = null;
let currentQty = 1;
let currentCategory = 'Sushi Menu';

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const money = n => `${Number(n).toLocaleString('en-US')} EGP`;

function normalizeItemName(name='') {
  return String(name).toLowerCase().replace(/\s+/g, ' ').trim();
}

function productImage(item, category='') {
  const n = normalizeItemName(item.name);
  if (ITEM_IMAGES[n]) return ITEM_IMAGES[n];
  if (n.includes('combo 40')) return ITEM_IMAGES['combo 40 of your choice except special rolls'];
  if (n.includes('combo 35')) return ITEM_IMAGES['combo 35 of your choice'];
  if (n.includes('combo 24')) return ITEM_IMAGES['combo 24'];
  if (n.includes('combo 16')) return ITEM_IMAGES['combo 16'];
  if (n.includes('combo 12')) return ITEM_IMAGES['combo 12'];
  if (n.includes('noodles')) return ASSETS.noodles;
  if (n.includes('crab salad')) return ASSETS.crab;
  if (n.includes('combo') || category === 'Combos') return ASSETS.combos;
  if (category === 'Special Rolls' || n.includes('pink') || n.includes('black') || n.includes('mango') || n.includes('signature')) return ASSETS.special;
  if (n.includes('sauce') || n.includes('wasabi') || n.includes('ginger') || n.includes('chopsticks') || n.includes('teriyaki')) return ASSETS.noodles;
  return ASSETS.sushi;
}

function saveCart() {
  localStorage.setItem('noriCart', JSON.stringify(cart));
}

function updateCounts() {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  $('#cartCountTop').textContent = count;
  $('#cartCountBottom').textContent = count;
}

function toast(message='Added to cart') { return; }

function addToCart(item, qty=1, notes='') {
  const key = `${item.name}__${notes}`;
  const found = cart.find(i => i.key === key);
  if (found) found.qty += qty;
  else cart.push({ key, name:item.name, price:item.price, ingredients:item.ingredients, image:item.image || productImage(item, item.category), qty, notes });
  saveCart();
  renderCart();
  updateCounts();
  toast(`${item.name} added`);
}

function setQty(key, nextQty) {
  cart = cart.map(i => i.key === key ? {...i, qty: Math.max(1, nextQty)} : i);
  saveCart(); renderCart(); updateCounts();
}

function removeFromCart(key) {
  cart = cart.filter(i => i.key !== key);
  saveCart(); renderCart(); updateCounts(); toast('Removed');
}

function getSubtotal() {
  return cart.reduce((s, i) => s + i.price * i.qty, 0);
}

function renderCart() {
  const wrap = $('#cartItems');
  if (!wrap) return;
  if (!cart.length) {
    wrap.innerHTML = `<div class="empty-cart">Your cart is empty. Add sushi from the menu.</div>`;
  } else {
    wrap.innerHTML = cart.map(item => `
      <article class="cart-item">
        <img src="${item.image}" alt="${item.name}">
        <div>
          <h4>${item.name}</h4>
          <p>${money(item.price)}</p>
          ${item.notes ? `<small>Note: ${escapeHTML(item.notes)}</small>` : ''}
          <div class="cart-qty">
            <button type="button" data-cart-minus="${item.key}" aria-label="Decrease ${item.name}">−</button>
            <b>${item.qty}</b>
            <button type="button" data-cart-plus="${item.key}" aria-label="Increase ${item.name}">+</button>
          </div>
        </div>
        <button class="remove-item" type="button" data-remove="${item.key}" aria-label="Remove ${item.name}">×</button>
      </article>
    `).join('');
  }
  const subtotal = getSubtotal();
  $('#subtotal').textContent = money(subtotal);
  $('#deliveryFee').textContent = money(cart.length ? DELIVERY_FEE : 0);
  $('#total').textContent = money(subtotal + (cart.length ? DELIVERY_FEE : 0));
}

function escapeHTML(str='') {
  return String(str).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

function buildOrderMessage(singleItem=null) {
  const name = $('#customerName')?.value?.trim() || '';
  const phone = $('#customerPhone')?.value?.trim() || '';
  const address = $('#customerAddress')?.value?.trim() || '';
  const payment = $('#paymentMethod')?.value || 'Cash';
  const promo = $('#promoCode')?.value?.trim() || '';
  const lines = [];
  lines.push('Hi NORI HOUSE, I want to order:');
  lines.push('');
  const orderItems = singleItem ? [singleItem] : cart;
  orderItems.forEach((item, index) => {
    lines.push(`${index+1}. ${item.name} x${item.qty || 1} — ${money(item.price * (item.qty || 1))}`);
    if (item.notes) lines.push(`   Note: ${item.notes}`);
  });
  if (!singleItem) {
    const subtotal = getSubtotal();
    lines.push('');
    lines.push(`Subtotal: ${money(subtotal)}`);
    lines.push(`Delivery: ${money(cart.length ? DELIVERY_FEE : 0)}`);
    lines.push(`Total: ${money(subtotal + (cart.length ? DELIVERY_FEE : 0))}`);
  }
  lines.push('');
  if (name) lines.push(`Name: ${name}`);
  if (phone) lines.push(`Phone: ${phone}`);
  if (address) lines.push(`Address: ${address}`);
  if (payment) lines.push(`Payment: ${payment}`);
  if (promo) lines.push(`Promo: ${promo}`);
  return encodeURIComponent(lines.join('\n'));
}

function openWhatsApp(message) {
  window.open(`https://wa.me/${WA}?text=${message}`, '_blank', 'noopener,noreferrer');
}


function isComboCustomizerProduct(item) {
  const n = normalizeItemName(item?.name || '');
  return n.includes('combo 35') || n.includes('combo 40');
}

function comboOptionsFor(item) {
  const n = normalizeItemName(item?.name || '');
  const regular = menuData['Sushi Menu'].map(i => i.name);
  const special = menuData['Special Rolls'].map(i => i.name);
  if (n.includes('combo 35')) return { items: [...regular, ...special], allowSpecial: true };
  if (n.includes('combo 40')) return { items: [...regular], allowSpecial: false };
  return { items: [], allowSpecial: false };
}

function renderComboCustomizer(item) {
  const box = $('#comboCustomizer');
  if (!box) return;
  if (!isComboCustomizerProduct(item)) {
    box.hidden = true;
    box.innerHTML = '';
    return;
  }
  const { items, allowSpecial } = comboOptionsFor(item);
  box.hidden = false;
  box.innerHTML = `
    <div class="combo-customizer-head">
      <h3>Customize your combo</h3>
      <p>${allowSpecial ? 'Choose from all regular sushi and special rolls.' : 'Choose from regular sushi only (special rolls are excluded).'}</p>
    </div>
    <div class="combo-options-grid">
      ${items.map(name => `<label class="combo-check"><input type="checkbox" value="${escapeHTML(name)}"> <span>${escapeHTML(name)}</span></label>`).join('')}
    </div>
    <div class="combo-game-picker">
      <span>Choose the game</span>
      <label><input type="radio" name="comboGame" value="Bank El Haz" checked> Bank El Haz</label>
      <label><input type="radio" name="comboGame" value="Snakes & Ladders"> Snakes & Ladders</label>
    </div>
    <p class="combo-note">Your exact mix will be confirmed with you on WhatsApp.</p>
  `;
}

function getModalCombinedNotes() {
  const note = $('#modalNotes')?.value?.trim() || '';
  if (!currentProduct || !isComboCustomizerProduct(currentProduct)) return note;
  const selected = $$('#comboCustomizer input[type="checkbox"]:checked').map(i => i.value);
  const game = $('#comboCustomizer input[name="comboGame"]:checked')?.value || 'Bank El Haz';
  const extra = [];
  if (selected.length) extra.push(`Choices: ${selected.join(', ')}`);
  if (game) extra.push(`Game: ${game}`);
  return [note, ...extra].filter(Boolean).join(' | ');
}

function renderFeatured() {
  const grid = $('#featuredGrid');
  grid.innerHTML = featuredProducts.map((item, index) => {
    const image = productImage(item, item.category);
    return `
      <article class="product-card reveal" data-tilt>
        <img src="${image}" alt="${item.name}" loading="lazy">
        <h3>${item.name}</h3>
        <p class="ingredients">${item.ingredients}</p>
        <div class="price">${money(item.price)}</div>
        <div class="product-actions">
          <button class="btn primary" type="button" data-add-featured="${index}">Add</button>
          <button class="btn secondary" type="button" data-open-featured="${index}">Details</button>
        </div>
      </article>
    `;
  }).join('');
  observeReveals();
}

function renderTabs() {
  const cats = Object.keys(menuData);
  $('#categoryTabs').innerHTML = cats.map(cat => `
    <button class="tab" role="tab" aria-selected="${cat === currentCategory}" data-category="${cat}" type="button">${cat}</button>
  `).join('');
}

function renderMenu() {
  const items = menuData[currentCategory];
  $('#menuList').innerHTML = items.map((item, index) => {
    const image = productImage(item, currentCategory);
    return `
      <article class="menu-item" style="animation-delay:${Math.min(index*25,250)}ms">
        <img src="${image}" alt="${item.name}" loading="lazy">
        <div>
          <h3>${item.name}</h3>
          <p class="ingredients">${item.ingredients}</p>
          <div class="price">${money(item.price)}</div>
          <div class="menu-actions">
            <button class="btn primary" type="button" data-add-menu="${index}">Add</button>
            <button class="btn secondary" type="button" data-open-menu="${index}">Details</button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function renderCombos() {
  const combos = menuData['Combos'];
  $('#comboGrid').innerHTML = combos.map((item, index) => `
    <article class="combo-card reveal" data-tilt>
      <img src="${productImage(item, 'Combos')}" alt="${item.name}" loading="lazy">
      <span class="badge">${item.badge}</span>
      <h3>${item.name}</h3>
      <p class="ingredients">${item.ingredients}</p>
      <div class="price">${money(item.price)} ${item.oldPrice ? `<span class="old-price">${money(item.oldPrice)}</span>` : ''}</div>
      <div class="product-actions">
        <button class="btn primary" type="button" data-add-combo="${index}">Order</button>
        <button class="btn secondary" type="button" data-open-combo="${index}">Details</button>
      </div>
    </article>
  `).join('');
  observeReveals();
}

function openProduct(item, category='Signature') {
  currentProduct = {...item, category, image:item.image || productImage(item, category)};
  currentQty = 1;
  $('#modalCategory').textContent = category;
  $('#modalName').textContent = currentProduct.name;
  $('#modalIngredients').textContent = currentProduct.ingredients;
  $('#modalPrice').textContent = money(currentProduct.price);
  renderComboCustomizer(currentProduct);
  $('#modalQty').textContent = currentQty;
  $('#modalNotes').value = '';
  $('#modalImage').src = currentProduct.image;
  $('#modalImage').alt = currentProduct.name;
  $('#modalImage').decoding = 'async';
  $('#productOverlay').classList.add('open');
  $('#productOverlay').setAttribute('aria-hidden', 'false');
  document.body.classList.add('no-scroll');
}

function closeProduct() {
  renderComboCustomizer(null);
  $('#productOverlay').classList.remove('open');
  $('#productOverlay').setAttribute('aria-hidden', 'true');
  document.body.classList.remove('no-scroll');
}

function openCart() {
  renderCart();
  $('#cartDrawer').classList.add('open');
  $('#cartDrawer').setAttribute('aria-hidden', 'false');
  document.body.classList.add('no-scroll');
}
function closeCart() {
  $('#cartDrawer').classList.remove('open');
  $('#cartDrawer').setAttribute('aria-hidden', 'true');
  document.body.classList.remove('no-scroll');
}

function observeReveals() {
  if (!window.__revealObserver) {
    window.__revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
          window.__revealObserver.unobserve(entry.target);
        }
      });
    }, {threshold:.12, rootMargin:'0px 0px -30px 0px'});
  }
  $$('.reveal:not(.show)').forEach(el => window.__revealObserver.observe(el));
}

function initTilt() {
  const allowTilt = window.matchMedia('(hover: hover) and (pointer: fine)').matches && window.innerWidth > 900;
  if (!allowTilt) return;
  $$('[data-tilt]').forEach(card => {
    card.addEventListener('pointermove', e => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - .5;
      const y = (e.clientY - r.top) / r.height - .5;
      card.style.transform = `perspective(900px) rotateY(${x*5}deg) rotateX(${-y*5}deg) translateY(-3px)`;
    }, {passive:true});
    card.addEventListener('pointerleave', () => { card.style.transform = ''; });
  });
}

function initDragRotate() {
  const box = $('[data-drag-rotate]');
  const img = $('#modalImage');
  let active = false, startX = 0, startY = 0, currentX = 0, currentY = 0;
  box.addEventListener('pointerdown', e => {
    active = true; startX = e.clientX; startY = e.clientY; box.setPointerCapture(e.pointerId); img.style.transition = 'none';
  });
  box.addEventListener('pointermove', e => {
    if (!active) return;
    currentX = e.clientX - startX; currentY = e.clientY - startY;
    const rot = Math.max(-18, Math.min(18, currentX / 8));
    img.style.transform = `translate(${currentX*.08}px, ${currentY*.08}px) rotate(${rot}deg) scale(1.03)`;
  });
  function endDrag(){
    if (!active) return;
    active = false; img.style.transition = 'transform .42s cubic-bezier(.2,.8,.2,1)'; img.style.transform = '';
  }
  box.addEventListener('pointerup', endDrag);
  box.addEventListener('pointercancel', endDrag);
}

function wireEvents() {
  $('#menuToggle').addEventListener('click', () => {
    const btn = $('#menuToggle');
    const links = $('#navLinks');
    btn.classList.toggle('open');
    links.classList.toggle('open');
    btn.setAttribute('aria-expanded', links.classList.contains('open'));
  });
  $$('#navLinks a').forEach(link => link.addEventListener('click', () => {
    $('#navLinks').classList.remove('open'); $('#menuToggle').classList.remove('open'); $('#menuToggle').setAttribute('aria-expanded','false');
  }));
  $('#openCart').addEventListener('click', openCart);
  $('#openCartBottom').addEventListener('click', openCart);
  $('#closeCart').addEventListener('click', closeCart);
  $('#cartDrawer').addEventListener('click', e => { if (e.target.id === 'cartDrawer') closeCart(); });
  $('#closeProduct').addEventListener('click', closeProduct);
  $('#productOverlay').addEventListener('click', e => { if (e.target.id === 'productOverlay') closeProduct(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeProduct(); closeCart(); }});

  $('#categoryTabs').addEventListener('click', e => {
    const tab = e.target.closest('[data-category]');
    if (!tab) return;
    currentCategory = tab.dataset.category;
    renderTabs();
    renderMenu();
  });

  document.addEventListener('click', e => {
    const addFeatured = e.target.closest('[data-add-featured]');
    const openFeatured = e.target.closest('[data-open-featured]');
    const addMenu = e.target.closest('[data-add-menu]');
    const openMenu = e.target.closest('[data-open-menu]');
    const addCombo = e.target.closest('[data-add-combo]');
    const openCombo = e.target.closest('[data-open-combo]');
    const minus = e.target.closest('[data-cart-minus]');
    const plus = e.target.closest('[data-cart-plus]');
    const remove = e.target.closest('[data-remove]');

    if (addFeatured) {
      const item = {...featuredProducts[Number(addFeatured.dataset.addFeatured)]};
      item.image = productImage(item, item.category);
      addToCart(item);
    }
    if (openFeatured) {
      const item = {...featuredProducts[Number(openFeatured.dataset.openFeatured)]};
      openProduct(item, item.category || 'Featured');
    }
    if (addMenu) {
      const item = {...menuData[currentCategory][Number(addMenu.dataset.addMenu)], category: currentCategory};
      item.image = productImage(item, currentCategory);
      addToCart(item);
    }
    if (openMenu) {
      const item = {...menuData[currentCategory][Number(openMenu.dataset.openMenu)]};
      openProduct(item, currentCategory);
    }
    if (addCombo) {
      const item = {...menuData['Combos'][Number(addCombo.dataset.addCombo)], category:'Combos'};
      item.image = productImage(item, 'Combos');
      addToCart(item);
    }
    if (openCombo) {
      const item = {...menuData['Combos'][Number(openCombo.dataset.openCombo)]};
      openProduct(item, 'Combos');
    }
    if (minus) {
      const item = cart.find(i => i.key === minus.dataset.cartMinus);
      if (item) setQty(item.key, item.qty - 1);
    }
    if (plus) {
      const item = cart.find(i => i.key === plus.dataset.cartPlus);
      if (item) setQty(item.key, item.qty + 1);
    }
    if (remove) removeFromCart(remove.dataset.remove);
  });

  $('#modalMinus').addEventListener('click', () => { currentQty = Math.max(1, currentQty - 1); $('#modalQty').textContent = currentQty; });
  $('#modalPlus').addEventListener('click', () => { currentQty++; $('#modalQty').textContent = currentQty; });
  $('#modalAdd').addEventListener('click', () => {
    if (!currentProduct) return;
    addToCart(currentProduct, currentQty, getModalCombinedNotes());
    closeProduct();
    openCart();
  });
  $('#modalWhatsApp').addEventListener('click', () => {
    if (!currentProduct) return;
    const item = {...currentProduct, qty: currentQty, notes: getModalCombinedNotes()};
    openWhatsApp(buildOrderMessage(item));
  });
  $('#sendOrder').addEventListener('click', () => {
    if (!cart.length) return toast('Cart is empty');
    openWhatsApp(buildOrderMessage());
  });
  $('#contactForm').addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const msg = encodeURIComponent(`Hi NORI HOUSE, I want to contact you.\nName: ${fd.get('name') || ''}\nPhone: ${fd.get('phone') || ''}\nMessage: ${fd.get('message') || ''}`);
    openWhatsApp(msg);
  });
}

function init() {
  renderFeatured();
  renderTabs();
  renderMenu();
  renderCombos();
  renderCart();
  updateCounts();
  observeReveals();
  initTilt();
  initDragRotate();
  wireEvents();
  window.addEventListener('load', () => setTimeout(() => $('#loader').classList.add('hide'), 450));
}

init();
